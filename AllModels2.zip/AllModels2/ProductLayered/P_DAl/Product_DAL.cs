﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using P_Entity;
using P_Exception;


namespace P_DAl
{
    public class Product_DAL
    {
        static string conStr = string.Empty;

        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();



        static Product_DAL()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;

        }

        public Product_DAL()
        {
            con = new SqlConnection(conStr);

        }

        public void AddProductDAL(Product pro)
        {
            //int pid = 0;
            try
            {
                //con = new SqlConnection();
                //con.ConnectionString = conStr; 
                cmd = new SqlCommand("addProduct_172324", con);

                //cmd.CommandText = "Nepun.udp_insert_patientDetails";
                //cmd.Connection = con;

                cmd.CommandType = CommandType.StoredProcedure;


                cmd.Parameters.AddWithValue("@ProductId", pro.ProductId);
                cmd.Parameters.AddWithValue("@ProductName",pro.ProductName);
                cmd.Parameters.AddWithValue("@Description",pro.Description);
                cmd.Parameters.AddWithValue("@UnitPrice",pro.UnitPrice);
                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                //pid = int.Parse(cmd.Parameters["@pId"].Value.ToString());
            }
            catch (ProductException)
            {
                throw;
            }

            catch (SqlException)
            {
                throw;
            }

            catch (SystemException)
            {
                throw;
            }

            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            //return pid;
        }

        public Product SearchProductDAL(int searchProductID)
        {
            Product SearchedProduct = new Product();
            try
            {
                con.ConnectionString = conStr;
                con.Open();
                //SqlCommand Command = new SqlCommand();
                cmd.Connection = con;
                string query = "searchProduct_172324";
                cmd.Parameters.AddWithValue("@ProductId", searchProductID);
                cmd.CommandText = query;
             
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                SqlDataReader Reader = cmd.ExecuteReader();
                if (Reader.HasRows)
                {
                    while (Reader.Read())
                    {
                        SearchedProduct.ProductId = int.Parse(Reader[0].ToString());
                        SearchedProduct.ProductName = Reader[1].ToString();
                        SearchedProduct.Description = Reader[2].ToString();
                        SearchedProduct.UnitPrice = decimal.Parse(Reader[3].ToString());
                    }
                }
            }
            catch (ProductException)
            {
                throw;
            }
            return SearchedProduct;
        }

        public DataTable DisplayProductDAL()
        {
            DataTable dt = null;
            try
            {
                cmd = new SqlCommand("DisplayProduct_172324", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
                

            }
            catch (ProductException)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw ex;

            }

            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

            return dt;
        }

        public int DeleteProductDAl(int productID)
        {
            try
            {
                cmd = new SqlCommand("DeleteProduct_172324", con);
                cmd.Parameters.AddWithValue("@ProductId", productID);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();

                int NumberOfRowsAdded = cmd.ExecuteNonQuery();
                return NumberOfRowsAdded;
            }
            catch (ProductException)
            {
                throw;
            }

            catch (SqlException)
            {
                throw;
            }

            catch (SystemException)
            {
                throw;
            }

            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

        }

        public bool UpdateProductDAL(Product productID)
        {
            Product up = new Product();
            up = productID;
            try
            {
                //con = new SqlConnection();
                //con.ConnectionString = conStr; 
                cmd = new SqlCommand("UpdateProduct_172324", con);
               

                //cmd.CommandText = "Nepun.udp_insert_patientDetails";
                //cmd.Connection = con;

                cmd.CommandType = CommandType.StoredProcedure;


                cmd.Parameters.AddWithValue("@ProductId", up.ProductId);
                cmd.Parameters.AddWithValue("@ProductName", up.ProductName);
                cmd.Parameters.AddWithValue("@Description", up.Description);
                cmd.Parameters.AddWithValue("@UnitPrice", up.UnitPrice);
                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                //pid = int.Parse(cmd.Parameters["@pId"].Value.ToString());
            }
            catch (ProductException)
            {
                throw;
            }

            catch (SqlException)
            {
                throw;
            }

            catch (SystemException)
            {
                throw;
            }

            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return true;
        
            
        }
    }
    
}
